/**
 * Pillar II — knowledge base (The Archetypal).
 *
 * Sourced background for the LLM that writes the archetypal pattern analysis,
 * and for the in-app "Knowledge & Sources" section.
 *
 * Provenance: compiled from the user's research notebook —
 *   • "Prophecy by Expectation: The Pygmalion Effect on Arrakis"
 *   • "The Ironic Ascension of Paul Atreides: Frye's Modes in Dune"
 *
 * WHY THESE BELONG HERE: both documents analyse archetypal POSSESSION — what
 * happens when a person is carried by a collective projection and comes to
 * identify with an archetype rather than relate to it. That is the central
 * clinical hazard of archetypal work, and Dune is a deliberate deconstruction
 * of the "Chosen One" narrative rather than a celebration of it. Used here as
 * literary-psychological illustration, not prophecy: the point is inflation and
 * its costs.
 */

export type ArchetypeKnowledgeEntry = {
  id: string;
  /** Archetype ids (data/archetypes.ts) or individuation stages this elaborates. */
  relatesTo: string[];
  topic: string;
  elaboration: string;
  mechanisms?: { name: string; body: string }[];
  /** A reflective prompt the report or the user can work with. */
  reflection?: string;
};

/* --------------------------------------------------- Frye's fictional modes */

export type FryeMode = {
  order: number;
  name: string;
  power: string; // the protagonist's power of action relative to others/environment
  inDune: string;
  psychological: string; // what it maps to in a person's self-narrative
};

/**
 * Northrop Frye's five fictional modes (Anatomy of Criticism), classified by the
 * protagonist's power of action relative to other people and their environment.
 * Presented in Dune's narrative order of ascent-then-collapse.
 */
export const FRYE_MODES: FryeMode[] = [
  {
    order: 1,
    name: 'High Mimetic — the Noble Leader',
    power: 'Superior to ordinary people, but strictly subject to nature and the constraints of society.',
    inDune:
      'Dune opens here. Paul is heir to Duke Leto, embedded in the rigid aristocratic caste system (the faufreluches) and constrained by the Padishah Empire, CHOAM, the Spacing Guild, and the ecology of Arrakis.',
    psychological:
      'You have real standing and real limits. Competence with humility — the healthiest ordinary position, and the one people leave too quickly.',
  },
  {
    order: 2,
    name: 'Romance — the Extraordinary Hero',
    power: 'Extraordinary or supernatural powers, marvellous adventures, still bound by the laws of legend.',
    inDune:
      'Exile into the desert. Mentat computation, Bene Gesserit nerve control, the awakening "inner eye," surviving the desert, hand-to-hand victory, and finally riding the sandworm — Frye\'s "dragon-taming" motif.',
    psychological:
      'The register of the personal myth. Genuine capacity discovered under pressure — energising, and the first place inflation can begin.',
  },
  {
    order: 3,
    name: 'Myth — the Divine Being',
    power: 'A deity or divine figure, superior in kind to both humans and environment.',
    inDune:
      'Elevated by the Bene Gesserit\'s Missionaria Protectiva and Fremen hope to Lisan al-Gaib and Mahdi. The Water of Life unlocks cosmic consciousness and connection to the ancestral collective unconscious.',
    psychological:
      'Identification with the archetype rather than relation to it. In Jungian terms: inflation, the mana personality. Feels like arrival; functions as capture.',
  },
  {
    order: 4,
    name: 'Ironic — the Powerless Captive',
    power: 'Powerless, frustrated, subjected to an absurd machinery of fate; inferior in agency.',
    inDune:
      'The subversion: myth collapses directly into irony. With god-like prescience and absolute power, Paul is still powerless to stop the Jihad waged in his name — a prisoner of his own constructed mythos and his followers\' fanaticism. Prescience grants no freedom; it locks in a "terrible purpose."',
    psychological:
      'The bill for inflation. Whoever becomes the archetype loses agency to it — the role now writes the person. Recognising this is the turning point of the work.',
  },
  {
    order: 5,
    name: 'Low Mimetic — Ordinary Reality',
    power: 'Ordinary people whose powers match the reader\'s; the register of realistic fiction.',
    inDune:
      'Paul is never a Low Mimetic figure, but Herbert aims a Low Mimetic warning at the reader: stripped of romance, the danger is surrendering critical thinking to a charismatic leader. The true victims are the ordinary millions who suffer because a society abdicated its judgement to a superhero.',
    psychological:
      'The ground to return to. Ordinary human scale is not a demotion — it is where responsibility, judgement, and relationship actually live.',
  },
];

/* ----------------------------------------------------- knowledge entries */

export const ARCHETYPE_KNOWLEDGE: ArchetypeKnowledgeEntry[] = [
  {
    id: 'pygmalion_effect',
    relatesTo: ['persona', 'shadow', 'hero', 'trickster_shadow', 'self'],
    topic: 'Prophecy by expectation — the Pygmalion Effect',
    elaboration:
      'The Pygmalion Effect is the phenomenon in which high expectations placed on a person lead them to perform exceptionally well; people internalise identity from their surroundings and from how others treat them. In Dune it is the mechanism that turns Paul Atreides into the Lisan al-Gaib. He begins hesitant, unsure he is worthy of leadership; the Bene Gesserit\'s planted propaganda and the Fremen\'s overwhelming trust artificially boost his capability until he can stand against the Harkonnens, the Emperor, and the Great Houses. His identity as messiah is not purely free will or innate destiny — it is substantially constructed by the expectations of the masses.',
    mechanisms: [
      {
        name: 'Elevation through expectation',
        body: 'Being treated as capable produces capability. Trust and high expectation function as real psychological resources — which is why they can lift a hesitant person into action they could not otherwise take.',
      },
      {
        name: 'Internalising the identity',
        body: 'Performance rests on the beliefs of the environment. Surrounded by zealous faith, Paul internalises it; the collective expectation resolves his cognitive dissonance and identity crisis — notably after discovering his Harkonnen heritage — and lets him adopt the persona as his own. Note the shadow logic: the projection arrives precisely where the self-knowledge is most unbearable.',
      },
      {
        name: 'The self-fulfilling prophecy',
        body: 'The Fremen are already conditioned to prepare a way for a savior. Once Paul shows a few signs matching the legend, the populace\'s boost makes the prophesied path the path of LEAST RESISTANCE. Prophecy does not predict; it recruits.',
      },
      {
        name: 'The role forecloses the alternative',
        body: 'A fairer path existed — the one Chani chooses — but the weight of expectation overrides alternatives, locking Paul into a "high-performing powerful antihero" fulfilling a bloody destiny he tried to avoid. Being carried is not the same as choosing.',
      },
    ],
    reflection:
      'Whose expectations have made you capable — and whose have made you into something you did not choose? Where is the path of least resistance being mistaken for your destiny?',
  },
  {
    id: 'frye_modes',
    relatesTo: ['hero', 'self', 'trickster_shadow', 'archetype'],
    topic: 'Frye\'s five modes and the deconstruction of the hero',
    elaboration:
      'Frye classifies literature into five fictional modes by the protagonist\'s power of action relative to others and environment: Myth, Romance, High Mimetic, Low Mimetic, and Ironic. Dune ascends the ladder of heroic power — High Mimetic to Romance to Myth — and then plunges into Irony. Herbert builds Paul up using those structures only to reveal, through the Ironic mode, the catastrophic danger of treating a human being as a god. Read psychologically, the modes are a diagnostic of where a person has located themselves in their own story.',
    mechanisms: [
      {
        name: 'Ascent is not progress',
        body: 'Moving "up" the modes toward myth feels like growth but is the mechanism of inflation. The Jungian caution is exact: relate to the archetype, do not become it.',
      },
      {
        name: 'Myth collapses into Irony',
        body: 'The higher the identification, the more total the loss of agency. Paul\'s omniscience does not free him — it imprisons him in a terrible purpose. In practice: the more someone is certain they are chosen, the less freedom they actually have.',
      },
      {
        name: 'The Low Mimetic return',
        body: 'The corrective is ordinary human scale — where judgement, responsibility, and relationship exist. Herbert\'s warning is addressed to the audience, not the hero: the cost of abdicating critical thinking to a charismatic figure is paid by ordinary people.',
      },
    ],
    reflection:
      'Which mode are you narrating your life in right now — noble leader, extraordinary hero, divine figure, powerless captive, or ordinary person? What would change if you deliberately stepped one mode down?',
  },
  {
    id: 'inflation_and_safety',
    relatesTo: ['self', 'trickster_shadow', 'shadow', 'persona'],
    topic: 'Inflation, the mana personality, and why this pillar stays grounded',
    elaboration:
      'Taken together, these two analyses describe the exact failure mode that archetypal work must avoid. Contact with archetypal material is genuinely energising, and that energy is easily misread as election — "I am the one." Jung called the result inflation, and the figure it produces the mana personality: guru, magician, chosen one. Dune\'s value here is that it follows the arc to its end and shows the bill: captivity to the role, violence done in one\'s name, and ordinary people paying for it. This is why the pillar treats archetypes as patterns to relate to consciously rather than identities to assume, and why the app frames its material as psychological metaphor rather than revelation.',
    reflection:
      'Where does your archetypal work make you feel special rather than more responsible? That is the place to slow down.',
  },
];

/* ------------- appended from the Framework / Architecture / Synthesis docs ------------- */

ARCHETYPE_KNOWLEDGE.push(
  {
    id: 'von_franz_method',
    relatesTo: ['archetype', 'dream', 'shadow'],
    topic: 'Von Franz’s hermeneutic — how to read archetypal material',
    elaboration:
      'Marie-Louise von Franz treated fairy tales as the "purest form" of archetypal images, and developed a repeatable method for interpreting them (and dreams). This is the framework the pillar’s "Analyze through Jungian Lens" report follows, in four steps.',
    mechanisms: [
      { name: '1 · Expositional diagnosis', body: 'Analyse the opening to diagnose the starting deficit, imbalance, or ossification in the protagonist’s conscious attitude. What is one-sided at the beginning is what the story exists to correct.' },
      { name: '2 · Systematic psychic mapping', body: 'Translate characters and settings into psychological structures: the protagonist as the emerging ego, the king or authority figure as the dominant conscious attitude (or father complex), monsters and rivals as the shadow.' },
      { name: '3 · Symbolic amplification', body: 'Connect the motifs to universal, cross-cultural myth and alchemical symbolism, expanding their meaning beyond personal association alone.' },
      { name: '4 · Psychodynamic synthesis', body: 'Evaluate the resolution against the beginning: did the psyche integrate its unconscious components (individuation), or succumb to regression?' },
    ],
    reflection: 'Applied to your own material: what was one-sided at the start, and did the ending actually change it — or only defend it better?',
  },
  {
    id: 'arrakis_as_psyche',
    relatesTo: ['dream', 'self', 'anima', 'collective'],
    topic: 'Arrakis as a map of the psyche',
    elaboration:
      'Herbert uses the geography of Arrakis as the architecture of a developing mind. The barren, visible surface reflects the conscious mind and the ego, where survival depends on technology and rationality; the hidden underground network of sietches and secret water caches represents the deep collective unconscious. Water — fiercely guarded, concealed — carries the Jungian charge: "water is no figure of speech, but a living symbol of the dark psyche." After his father’s death, Paul is thrust into a desert of spiritual and moral isolation: a necessary exile that forces the soul to seek those deep waters.',
    mechanisms: [
      { name: 'The Water of Life as descent', body: 'Drinking the poisonous exhalation of a dying sandworm is the descent into the monster’s belly — Eliade: "One goes down into the belly of a giant monster in order to learn science or wisdom." The three-week coma synthesises conscious mind with ancestral memory.' },
      { name: 'Anima integration', body: 'The transformation requires integrating the anima. The Reverend Mother prophesies one who can "look where we cannot — into both feminine and masculine pasts." Surviving the Water of Life awakens a pre-rational, somatic intuition bridging conscious and unconscious.' },
      { name: 'Ancestral memory ≈ collective unconscious', body: 'Herbert’s ancestral memory parallels Jung’s collective unconscious: Paul must integrate the voices of opposing ancestors — Atreides and Harkonnen — into a single mind. The cognitive dissonance between his fair Atreides identity and cruel Harkonnen roots is resolved by choosing ruthlessness, which is what turns him antihero.' },
    ],
    reflection: 'Where is your own “hidden water” — the thing guarded underground? And what exile is currently forcing you toward it?',
  },
  {
    id: 'seeker_and_liminality',
    relatesTo: ['hero', 'divine_child', 'rebirth'],
    topic: 'The Seeker, sacred restlessness, and liminality',
    elaboration:
      'The Seeker archetype is characterised by a quest for authenticity and self-discovery, driven by a "sacred restlessness" or divine discomfort that propels one from known horizons into the deep — of the world and of the psyche. Crises function as liminal landscapes. Victor Turner’s rite of passage has three phases: SEPARATION (moving away from the ordinary world), LIMINALITY (uncertainty, ambiguity, ordeal — "betwixt and between" stable identities), and RE-INCORPORATION (returning with new status). In liminal periods a spirit of communitas can emerge: shared attunement and bonding strengthened by love and common purpose.',
    mechanisms: [
      { name: 'Survival as adaptability', body: '"Survival is the ability to swim in strange water." The Seeker must enter the cave they are afraid of to find the source of their purpose.' },
      { name: 'Confirmation bias as trap', body: 'The Fremen interpret every action of Paul’s through their prophecy and ignore contradictory data to preserve hope. Collective belief hardens into a cage: he is trapped by their reading of him.' },
    ],
    reflection: 'Which phase are you in — separation, liminality, or re-incorporation? And what are you refusing to enter?',
  },
  {
    id: 'fairy_tales_and_diamond_body',
    relatesTo: ['archetype', 'maiden', 'great_mother', 'rebirth'],
    topic: 'Fairy tales, the Gretel moment, and the diamond body',
    elaboration:
      'Von Franz viewed fairy tales as the purest archetypal images. Two ideas carry directly into practice. The "Gretel moment" — pushing the witch into the oven — represents a decisive choice to align with Eros and say yes to life: a model for taking action against what threatens existence. And the "diamond body": von Franz theorised that a person constructs a soul-body capable of surviving the "fire of death" precisely by making elements of their life conscious. Consciousness is not decoration; it is what is built.',
    reflection: 'Where is your Gretel moment — the decisive act you keep deferring? And what part of your life is still unconscious, and so not yet built into the diamond body?',
  },
  {
    id: 'maternal_imago_and_projection',
    relatesTo: ['great_mother', 'shadow', 'self'],
    topic: 'Shadow projection and the maternal imago (Book of Baruch)',
    elaboration:
      'Post-Jungian reading of the apocryphal Book of Baruch offers a model of shadow integration. References to the "sins of the fathers" are read as allegory for psychological projection — locating moral deficiency in others rather than oneself — while the contrite spirit and confession represent the first stage of individuation, where the ego acknowledges its own dark characteristics. Jerusalem functions as the primordial mother or mother imago; the longing to return to it can be read as a regressive wish for an anxiety-free, paradisiacal unconsciousness. Notably, the text also subverts Jung’s often anti-feminist framing: its mother figure is strong and urges her children toward courage and independence rather than devouring them. The Greek terms episteme (knowledge) and sophia (wisdom) are juxtaposed with light, which correlates with the Self as a totality indistinguishable from a God-image.',
    reflection: 'Whose “sins of the fathers” are you cataloguing? And where does your longing to go home actually mean a longing to stop being conscious?',
  },
  {
    id: 'chosen_one_scholarship',
    relatesTo: ['hero', 'self', 'trickster_shadow'],
    topic: 'Peer-reviewed finding: collective belief DISRUPTS individuation',
    elaboration:
      'Widyadhana & Haryanti (2026), in Language Literacy, read the Chosen One archetype in Dune through archetype and individuation. Their finding is pointed: Paul’s position as the Chosen One emerges through the Bene Gesserit’s influence, the Fremen’s expectations, and the continuous interpretation of his actions inside a prophetic framework — and his individuation "does not develop according to Jung’s ideal model, as his identity becomes increasingly shaped by collective expectations rather than personal integration." They argue Jungian literary criticism should attend more to how collective belief shapes archetypal identity and DISRUPTS individuation, and read Herbert as critiquing messianism and excessive faith in a savior figure.',
    mechanisms: [
      {
        name: 'A scholarly disagreement worth holding',
        body: 'One of the source documents for this pillar states that Paul "successfully undergoes individuation." The peer-reviewed study argues the opposite — that collective expectation displaced genuine integration. Both readings are recorded here deliberately: the disagreement is the useful part, because it is exactly the question a person must ask of their own development. Is this integration, or is it other people’s expectations wearing the costume of integration?',
      },
    ],
    reflection: 'Test your own progress by that standard: is what you call growth personally integrated — or is it a role your circle has agreed you now occupy?',
  },
);

export const archetypeKnowledgeFor = (id: string) =>
  ARCHETYPE_KNOWLEDGE.filter((k) => k.relatesTo.includes(id));

/* ----------------------------------------------- Frye's seasonal archetypes */

export type SeasonalArchetype = {
  season: string;
  plot: string;
  mythicGoal: string;
  psychological: string;
};

/** Frye distributes archetypal images into categories analogous to the seasons. */
export const SEASONAL_ARCHETYPES: SeasonalArchetype[] = [
  { season: 'Spring', plot: 'Comedy', mythicGoal: 'New world / miraculous resolution', psychological: 'Re-incorporation; birth' },
  { season: 'Summer', plot: 'Romance', mythicGoal: 'Quest for cultural values; idealised worlds', psychological: 'The Hero’s journey; the Seeker' },
  { season: 'Autumn', plot: 'Tragedy', mythicGoal: 'The fall of a hero from a high position; loss', psychological: 'The fall of the ego' },
  { season: 'Winter', plot: 'Irony / Satire', mythicGoal: 'Destruction of illusions; mocking the heroic', psychological: 'Shadow encounter; cold reality' },
];

/** Quotes supplied with the sources, usable in reports and in the UI. */
export const ARCHETYPE_QUOTES: { text: string; attribution: string }[] = [
  { text: 'The journey of the hero is about the courage to seek the depths; the image of creative rebirth; the eternal cycle of change within us.', attribution: 'Phil Cousineau' },
  { text: 'Dreams are messages from the deep.', attribution: 'Dune (2021)' },
  { text: 'Who looks outside, dreams; who looks inside, awakes.', attribution: 'C. G. Jung' },
  { text: 'Arrakis teaches the attitude of the knife — chopping off what’s incomplete and saying: “Now, it’s complete because it’s ended here.”', attribution: 'Frank Herbert' },
  { text: 'The whole is greater than the sum of its parts.', attribution: 'Gestalt psychology principle' },
  { text: 'One goes down into the belly of a giant monster in order to learn science or wisdom.', attribution: 'Mircea Eliade' },
];

/** Compact briefing handed to the LLM for the archetypal-pattern analysis. */
export function archetypeKnowledgeBriefing(): string {
  const topics = ARCHETYPE_KNOWLEDGE.map((k) => {
    const mechs = (k.mechanisms ?? []).map((m) => `  - ${m.name}: ${m.body}`).join('\n');
    return `TOPIC: ${k.topic}\n${k.elaboration}${mechs ? `\nMechanisms:\n${mechs}` : ''}${
      k.reflection ? `\nReflection: ${k.reflection}` : ''
    }`;
  }).join('\n\n');

  const modes = FRYE_MODES.map(
    (m) => `  ${m.order}. ${m.name} — power: ${m.power} | psychologically: ${m.psychological}`,
  ).join('\n');

  const seasons = SEASONAL_ARCHETYPES.map(
    (s) => `  - ${s.season} / ${s.plot}: ${s.mythicGoal} → psychologically: ${s.psychological}`,
  ).join('\n');

  return [
    topics,
    `FRYE'S FIVE FICTIONAL MODES (as a diagnostic of self-narration):\n${modes}`,
    `FRYE'S SEASONAL ARCHETYPES (plot ↔ psychological parallel):\n${seasons}`,
  ].join('\n\n');
}

/** Sources supplied for this pillar. */
export const ARCHETYPE_SOURCES: { title: string; note: string; author?: string; date?: string; url?: string }[] = [
  {
    title: 'Prophecy by Expectation: The Pygmalion Effect on Arrakis',
    note: 'How collective expectation constructs the messianic identity of Paul Atreides.',
  },
  {
    title: 'The Ironic Ascension of Paul Atreides: Frye\'s Modes in Dune',
    note: 'Northrop Frye\'s five fictional modes (Anatomy of Criticism) applied to Dune\'s ascent and ironic collapse.',
  },
  {
    title: 'The Archetypal Framework: A Guide to Jungian Individuation',
    note: 'Blueprint for this pillar: von Franz\'s hermeneutic, the gallery with shadow forms, and the movements of individuation.',
  },
  {
    title: 'The Jungian Architecture of Paul Atreides',
    note: 'Arrakis as a map of the psyche; the Water of Life, anima integration, and the danger of the Chosen One archetype.',
  },
  {
    title: 'Synthesis of Archetypal Criticism, Depth Psychology, and Mythic Narrative',
    note: 'Frye\'s modes and seasonal archetypes, the Book of Baruch, liminality and communitas, von Franz on fairy tales, and the psychological drivers in Dune.',
  },
  {
    title: 'Reconstructing the Chosen One Archetype in Frank Herbert\'s Dune: A Jungian Reading of Collective Belief and Individuation',
    note: 'Peer-reviewed: finds Paul\'s individuation does NOT follow Jung\'s ideal model — collective expectation displaces personal integration.',
    author: 'Widyadhana, M. R. & Haryanti, R. P.',
    date: '2026',
    url: 'https://doi.org/10.30743/ll.v10i1.13847',
  },
  {
    title: 'Dreams from the Deep: The Sacred Restlessness of the Seeker\'s Path',
    note: 'The Seeker archetype and "sacred restlessness"; Dune, the Hero\'s Journey, Anatomy of Criticism.',
    author: 'Jason D. Batt, PhD',
    date: '14 Aug 2025',
    url: 'https://www.jcf.org/post/dreams-from-the-deep',
  },
  {
    title: 'Strange Water: An Exile into the Deep Self in Frank Herbert\'s Dune',
    note: 'Exile into the deep; water as living symbol of the dark psyche.',
    author: 'Jason D. Batt, MFA',
    date: '2020',
    url: 'https://www.pacifica.edu',
  },
  {
    title: 'The Interpretation of Fairy Tales',
    note: 'Von Franz\'s method; fairy tales as the purest archetypal images.',
    author: 'Marie-Louise von Franz',
    url: 'https://www.jungian-confrerie.com/the-interpretation-of-fairy-tales/',
  },
  {
    title: 'Archetypal Criticism / Myth Criticism of Northrop Frye',
    note: 'Frye\'s modes, seasonal archetypes, and the lineage of archetypal criticism.',
    author: 'Nasrullah Mambrol',
    url: 'https://literariness.org/2020/10/22/archetypal-criticism/',
  },
  {
    title: 'Anatomy of Criticism by Northrop Frye (research starter)',
    note: 'Reference overview of Frye\'s system.',
    url: 'https://www.ebsco.com/research-starters/literature-and-writing/anatomy-criticism-northrop-frye',
  },
  {
    title: 'Archetype theory (Christian Roesler)',
    note: 'Contemporary empirical re-examination of archetype theory.',
    url: 'https://www.cgjung.net/espace/jps/articles/christian-roesler/archetype-theory/',
  },
  {
    title: 'The Mother Complex and the Great Mother',
    note: 'The maternal imago and the devouring-mother dynamic.',
    url: 'https://www.jungian-confrerie.com/blog/the-mother-complex-and-the-great-mother/',
  },
];
