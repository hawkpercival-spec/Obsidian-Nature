/**
 * Thin client for the analysis backend.
 *
 * SECURITY: the LLM provider key must NEVER live in the app. Anything bundled
 * ships to every device and can be extracted from the IPA — there is no
 * obfuscation that fixes this. The app therefore calls YOUR server, which holds
 * the key and calls the model. See server/ for a reference implementation.
 *
 * DIFFERENCE FROM THE MAIN APP: the app's copy of this file reads the base URL
 * from `expo-constants` and the session cookie from `@better-auth/expo`
 * directly. This bundle takes both by injection instead, so it has zero runtime
 * dependencies and can be type-checked and unit-tested standalone. Wiring it
 * back into the app is one call at startup:
 *
 *   import Constants from 'expo-constants';
 *   import { authClient } from '@/auth/auth';
 *
 *   const extra = (Constants.expoConfig?.extra ?? {}) as Record<string, string>;
 *   configureAnalysis({
 *     baseUrl: extra.analysisBaseUrl || extra.authBaseUrl || '',
 *     getCookie: () => (authClient as any).getCookie?.() ?? null,
 *   });
 *
 * `baseUrl` is a PUBLIC value — your own hostname, nothing more. No secret
 * passes through this file.
 */

export type AnalysisConfig = {
  /** Base URL of your backend, e.g. https://api.example.com. Public value. */
  baseUrl: string;
  /** Returns the better-auth session cookie, or null when signed out. */
  getCookie?: () => string | null | undefined;
  /** Request timeout. Defaults to 30s. */
  timeoutMs?: number;
};

let config: AnalysisConfig = { baseUrl: '' };

/** Call once at app startup. */
export function configureAnalysis(next: AnalysisConfig): void {
  config = next;
}

/**
 * True only when a real (non-placeholder) endpoint is configured.
 *
 * Placeholders are rejected deliberately: committed example values like
 * `https://example.com` or `YOUR_API_HOST` keep the app on its offline
 * generator rather than firing requests that are guaranteed to fail.
 */
export function analysisConfigured(): boolean {
  const b = config.baseUrl ?? '';
  return b.length > 0 && !/YOUR_|localhost|example\.com/i.test(b);
}

const DEFAULT_TIMEOUT_MS = 30000;

export async function requestAnalysis<T>(kind: string, payload: unknown): Promise<T> {
  if (!analysisConfigured()) throw new Error('analysis endpoint not configured');

  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  try {
    const cookie = config.getCookie?.();
    if (cookie) headers.Cookie = cookie;
  } catch {
    /* not signed in / no cookie — the server will reject, which triggers the
       local fallback in remote.ts. Nothing to handle here. */
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), config.timeoutMs ?? DEFAULT_TIMEOUT_MS);
  try {
    const res = await fetch(`${config.baseUrl.replace(/\/$/, '')}/api/analysis/${kind}`, {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
      signal: controller.signal,
    });
    if (!res.ok) throw new Error(`analysis/${kind} responded ${res.status}`);
    return (await res.json()) as T;
  } finally {
    clearTimeout(timer);
  }
}

/** Shape the server returns for report-style endpoints. */
export type RemoteReport = {
  title: string;
  narrative: string;
  focusAreas: string[];
  archetypes?: string[];
  grade?: {
    letter: 'A' | 'B' | 'C' | 'D' | 'Incomplete';
    registers: { imaginary: number; symbolic: number; real: number };
    commentary: string;
  };
};
