import { AnalysisTone, ArchetypalInput, LacanianReport } from '@/types';

/**
 * Deterministic local generator for the ARCHETYPE INTAKE report — the one built
 * from the user's favourite films, books, fairytales and characters.
 *
 * In the full app these two functions live in `src/analysis/lacanian.ts`, the
 * 22KB module shared by every pillar. They are extracted here, unchanged, so
 * this bundle stands alone without dragging in the other six pillars' report
 * generators. If you merge this into the main project, delete this file and
 * import from `@/analysis/lacanian` instead.
 *
 * This is the OFFLINE path. `remote.ts` calls the LLM first and falls back to
 * this on any failure.
 */

const uid = () => Math.random().toString(36).slice(2) + Date.now().toString(36);

/** Tone helper — clinician mode addresses the treating analyst about the patient. */
function open(tone: AnalysisTone, name?: string | null) {
  return tone === 'clinician'
    ? `Case note for the treating analyst. The following formulation is offered as material for your work with this analysand${name ? ` (${name})` : ''}, not as a substitute for your clinical judgement.`
    : `You arrive as a subject divided — as all speaking beings are. Read this not as a verdict but as a map of where your speech has been circling.`;
}

function subj(tone: AnalysisTone) {
  return tone === 'clinician' ? 'the analysand' : 'you';
}

/**
 * Keyword detection over the intake text.
 *
 * Deliberately crude — it is the fallback, not the analysis. The LLM path reads
 * the same material with the knowledge base attached and does far better. What
 * this guarantees is that the user always gets *something* structured back.
 */
export function detectArchetypes(input?: ArchetypalInput): string[] {
  if (!input) return [];
  const text = `${input.movies} ${input.books} ${input.fairytales} ${input.characters}`.toLowerCase();
  const map: [string, string[]][] = [
    ['The Shadow', ['villain', 'dark', 'monster', 'evil', 'joker', 'vader', 'wolf']],
    ['The Hero', ['hero', 'quest', 'warrior', 'knight', 'skywalker', 'harry', 'aragorn']],
    ['The Orphan / Innocent', ['orphan', 'child', 'lost', 'cinderella', 'oliver']],
    ['The Sage / Mentor', ['wizard', 'mentor', 'teacher', 'gandalf', 'dumbledore', 'yoda']],
    ['The Lover', ['love', 'romance', 'passion', 'juliet']],
    ['The Rebel / Outlaw', ['rebel', 'outlaw', 'anti-hero', 'thief', 'robin']],
    ['The Caregiver', ['mother', 'nurse', 'protector', 'guardian']],
    ['The Trickster', ['trickster', 'loki', 'fox', 'jester', 'coyote']],
    ['The Ruler', ['king', 'queen', 'throne', 'ruler', 'emperor']],
    ['The Magician / Alchemist', ['magic', 'alchemist', 'transform', 'witch']],
  ];
  const found = map.filter(([, keys]) => keys.some((k) => text.includes(k))).map(([a]) => a);
  // Always give the shadow its due in this app.
  if (!found.includes('The Shadow')) found.push('The Shadow (implicit — to be surfaced)');
  return Array.from(new Set(found)).slice(0, 6);
}

export function generateArchetypeReport(tone: AnalysisTone, input?: ArchetypalInput): LacanianReport {
  const archetypes = detectArchetypes(input);
  const S = subj(tone);
  const narrative = [
    open(tone),
    `\nFrom the stories ${S} love${tone === 'clinician' ? 's' : ''}, we read the archetypal field — the cast of figures through which the psyche stages itself. Jung would call these the inhabitants of the collective unconscious as they appear in personal material; Lacan would remind us they are also signifiers, positions in a structure.`,
    `\nSurfaced archetypes: ${archetypes.join(', ')}.`,
    `\nBring these to your analyst. The figures you are drawn to often carry ideal-ego material; the ones you cannot stand usually carry the shadow — the obsidian nature you have exiled. Both are you.`,
  ].join('\n');
  return {
    id: uid(),
    createdAt: Date.now(),
    tone,
    title: 'Archetypal Explorations',
    narrative,
    focusAreas: archetypes.map((a) => `work the projection carried by ${a}`),
    archetypes,
  };
}
