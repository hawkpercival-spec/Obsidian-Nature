import { generateArchetypalPatternReport as localArchetypalPattern } from './archetypal';
import { generateArchetypeReport as localArchetypeReport } from './archetypeIntake';
import { archetypeKnowledgeBriefing } from '@/data/archetypesKnowledge';
import { requestAnalysis, RemoteReport, analysisConfigured } from './endpoint';
import { AnalysisTone, ArchetypalInput, LacanianReport } from '@/types';

export { analysisConfigured };

/**
 * Pillar II — "The Archetypal" async analysis layer.
 *
 * This is the seam between the app and the LLM. Each function calls YOUR
 * backend and, on ANY failure — endpoint not configured, offline, timeout,
 * non-2xx, malformed JSON — falls back to the deterministic local generator.
 * The app therefore always produces a report.
 *
 * SECURITY: no key, token, or credential appears in this file or anywhere else
 * in the client. Anything bundled into the app ships to every device and can be
 * extracted from the IPA. The model key lives only on the server, as an
 * environment variable. See server/README.md.
 */

const uid = () => Math.random().toString(36).slice(2) + Date.now().toString(36);

/** Convert the server's JSON into the app's report shape. */
function wrapReport(tone: AnalysisTone, r: RemoteReport, extra?: Partial<LacanianReport>): LacanianReport {
  return {
    id: uid(),
    createdAt: Date.now(),
    tone,
    title: r.title,
    narrative: r.narrative,
    focusAreas: r.focusAreas ?? [],
    archetypes: r.archetypes,
    grade: r.grade,
    ...extra,
  };
}

/**
 * The INTAKE archetype report — built from favourite films, books, fairytales
 * and characters. Surfaces in the "Archetypal Explorations" tab.
 *
 * Note this call sends no `knowledge` briefing: it runs during intake, before
 * the pillar is opened, and is deliberately a lighter read.
 */
export async function generateArchetypeReport(
  tone: AnalysisTone,
  input?: ArchetypalInput,
): Promise<LacanianReport> {
  try {
    const r = await requestAnalysis<RemoteReport>('archetype-report', { tone, input });
    return wrapReport(tone, r);
  } catch {
    return localArchetypeReport(tone, input);
  }
}

/**
 * "Analyze through Jungian Lens" — the Pillar II working button. Takes the
 * analysand's free reflection and reads it through von Franz's four-step
 * hermeneutic, with the full knowledge base attached.
 */
export async function analyzeArchetypalPattern(
  tone: AnalysisTone,
  text: string,
): Promise<LacanianReport> {
  try {
    const r = await requestAnalysis<RemoteReport>('archetypal-pattern', {
      tone,
      text,
      // Sourced background: von Franz's four steps, Frye's modes and seasons,
      // the individuation movements, and the Pygmalion-effect material on
      // archetypal possession. Built from data/archetypesKnowledge.ts.
      knowledge: archetypeKnowledgeBriefing(),
    });
    return wrapReport(tone, r, { pillarId: 2 });
  } catch {
    return localArchetypalPattern(tone, text);
  }
}
