/**
 * Minimal type surface for the Pillar II bundle.
 *
 * Copied verbatim from the main app's `src/types.ts` so the files here compile
 * standalone. If you are dropping this bundle into the full Obsidian Nature
 * project, DELETE this file and let the imports resolve to the app's own
 * `@/types` — the definitions are identical, and keeping two copies is how they
 * drift apart.
 */

/** 'clinician' = the user answered yes to "are you working with an analyst?". */
export type AnalysisTone = 'patient' | 'clinician';

/** Grading against the (self-)Lacanian rubric used across all seven pillars. */
export type PillarGrade = {
  letter: 'A' | 'B' | 'C' | 'D' | 'Incomplete';
  registers: { imaginary: number; symbolic: number; real: number }; // 0-100
  commentary: string;
};

export type LacanianReport = {
  id: string;
  createdAt: number;
  tone: AnalysisTone;
  title: string;
  narrative: string;
  focusAreas: string[];
  archetypes?: string[];
  grade?: PillarGrade; // present on per-pillar formulation reports
  pillarId?: number;
};

/**
 * The Jungian archetypal intake: favourite films, books, fairytales and
 * characters. Read as projective material — what a person loves and what they
 * cannot stand both carry.
 */
export type ArchetypalInput = {
  movies: string;
  books: string;
  fairytales: string;
  characters: string;
};
