/**
 * Prompt builders for the Pillar II ("The Archetypal") analysis endpoints.
 *
 * The SYSTEM prompt encodes the app's guardrails; each builder returns the user
 * message plus the exact JSON shape we want back. Keeping the schema here — in
 * the prompt, not in the model's head — is what makes responses parseable.
 *
 * SECURITY: this file contains no credentials. The model API key is read from
 * the environment in analysis.route.ts and never appears in source or in the
 * mobile bundle.
 */

export const SYSTEM_PROMPT = `You are the analysis engine behind "Obsidian Nature", a patient-facing
psychotraumatology self-analysis app. You write in an informed Lacanian register, drawing also on
Freudian and Jungian concepts, for a single user doing their own case-study work between sessions.

HARD RULES:
- Stay grounded in reality-based psychology. NO mysticism, magic, spirits, astrology, energy, or
  anything supernatural presented as literal. The app's occult aesthetic is metaphor only.
- "Obsidian nature" = the shadow: disowned aspects of personality, cognition, and behaviour.
- Never diagnose, never claim to treat, never replace professional care. You are a reflective tool.
- Do not moralise or shame. Be precise, humane, and specific to the material given.
- If the user works with an analyst (tone = "clinician"), address the treating clinician about the
  analysand and frame everything as case material to verify in session. Otherwise (tone = "patient"),
  address the user as "you".
- Avoid crisis territory. If the material suggests risk of self-harm, keep output supportive and
  gently point toward professional / crisis support rather than analysing further.

OUTPUT: Always reply with a SINGLE valid JSON object matching the requested schema. No markdown, no
prose outside the JSON, no code fences.`;

type Json = Record<string, unknown>;

const REPORT_SCHEMA = `{
  "title": string,
  "narrative": string,   // 3-6 short paragraphs, separated by \\n\\n
  "focusAreas": string[] // 3-6 concise items to cultivate/strengthen
}`;

/**
 * Kinds this bundle serves. The full app registers twelve; this Pillar II
 * export carries two. Add the others back when you merge into the main server.
 */
export const VALID_KINDS = new Set(['archetype-report', 'archetypal-pattern']);

export function buildPrompt(kind: string, payload: Json): { user: string; schema: string } {
  switch (kind) {
    /* ---- the intake read: favourite films, books, fairytales, characters ---- */
    case 'archetype-report':
      return {
        schema: REPORT_SCHEMA,
        user: `From the user's favourite media, surface the archetypal field (Jungian, read also as
Lacanian positions). Name specific archetypes and what to work with an analyst. Put the archetype
names in focusAreas.\nInputs:\n${JSON.stringify(payload, null, 2)}\nReturn JSON: ${REPORT_SCHEMA}`,
      };

    /* ---- the pillar's working button: "Analyze through Jungian Lens" ---- */
    case 'archetypal-pattern':
      return {
        schema: REPORT_SCHEMA,
        user: `Pillar II — "Analyze through Jungian Lens". Structure the report on Marie-Louise von
Franz's hermeneutic for fairy tales and dreams, in four explicit steps:
  1. EXPOSITIONAL DIAGNOSIS — read the opening for the starting deficit, imbalance, or ossification in
     the conscious attitude that the material begins from.
  2. SYSTEMATIC PSYCHIC MAPPING — translate figures and settings into psychological structures:
     protagonist = emerging ego; king/authority = dominant conscious attitude or father complex;
     monsters/rivals = shadow; helpers = mediating functions.
  3. SYMBOLIC AMPLIFICATION — connect motifs to cross-cultural myth, fairytale, and alchemical imagery
     so meaning expands beyond personal association.
  4. PSYCHODYNAMIC SYNTHESIS — evaluate the resolution against the beginning: did the psyche integrate
     the unconscious component (individuation), or regress?
Then identify which Jungian archetypes are ACTIVE in the psyche — from the
structural set (Ego, Persona, Shadow, Anima, Animus, Self) and the figures (Great Mother, Father,
Wise Old Man/Senex, Divine Child, Kore/Maiden, Hero, Trickster, Wounded Healer, Syzygy, Puer
Aeternus, Mana Personality, Rebirth). For each active archetype, note how it appears and its shadow
form. Frame the work as individuation (integrate, don't be possessed). Do NOT fix a single universal
meaning; give working material. Put the active archetype names in focusAreas.
If a "knowledge" string is present, it is SOURCED BACKGROUND on archetypal POSSESSION — the Pygmalion
Effect (collective expectation constructs identity; prophecy recruits rather than predicts; the role
forecloses alternatives) and Northrop Frye's five fictional modes read as a diagnostic of how a person
narrates their own life (High Mimetic → Romance → Myth = ascent into inflation; Myth collapses into
Ironic captivity; Low Mimetic = the grounded return). USE it to name inflation accurately where you
see it, and — importantly — to keep the reading GROUNDED: archetypes are patterns to relate to, never
identities to assume. If the material shows someone feeling chosen or special rather than more
responsible, say so plainly and gently.
Inputs:\n${JSON.stringify(payload, null, 2)}\nReturn JSON: ${REPORT_SCHEMA}`,
      };

    default:
      throw new Error(`unknown prompt kind: ${kind}`);
  }
}
