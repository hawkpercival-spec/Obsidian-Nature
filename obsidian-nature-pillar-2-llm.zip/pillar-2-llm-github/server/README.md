# Pillar II analysis backend

Reference implementation of the endpoints the app calls. Express + better-auth + Claude.

## Why this exists

The app must never hold the model key. Anything bundled into a React Native build
ships to every device and can be pulled out of the IPA. So the app calls this service,
this service holds the key in an environment variable, and this service calls Claude.

## Setup

```bash
cp ../.env.example .env         # fill in ANTHROPIC_API_KEY, BETTER_AUTH_SECRET, ...
npm install express @anthropic-ai/sdk better-auth
npm run dev
```

Mount the router on the **same origin** as better-auth, so the session cookie the app
sends is valid here:

```ts
import express from 'express';
import { analysisRouter } from './analysis.route';

const app = express();
app.use(express.json({ limit: '1mb' }));
app.use(analysisRouter);
app.listen(process.env.PORT ?? 3000);
```

Then point the app at it — `app.json` → `extra.analysisBaseUrl` and `extra.authBaseUrl`.
Both are public hostnames, safe to commit.

## The endpoint

```
POST /api/analysis/archetypal-pattern
Cookie: <better-auth session>

{ "tone": "patient" | "clinician",
  "text": "<the analysand's free reflection>",
  "knowledge": "<briefing string>" }

POST /api/analysis/archetype-report
{ "tone": ..., "input": { "movies", "books", "fairytales", "characters" } }

200 → { "title", "narrative", "focusAreas": [] }
```

| Status | Meaning | Client behaviour |
|---|---|---|
| 401 | no valid session | falls back to local generator |
| 404 | kind not in `VALID_KINDS` | falls back |
| 429 | over 40 req/hour for this user | falls back |
| 502 | model returned unparseable JSON | falls back |
| 500 | anything else | falls back |

Every failure path is silent to the user by design — `remote.ts` catches and produces
the deterministic local report instead. A backend outage degrades report quality; it
never blocks the pillar.

## Privacy

Request bodies contain the user's journals and exercise responses.

- The route logs the error and the kind. **It never logs the body.** Keep it that way.
- Nothing is persisted server-side by this bundle.
- If you add persistence, add a retention policy with it.

## Before production

- Swap the in-memory rate limiter for Redis — it is per-process, so it does nothing
  useful behind more than one instance.
- Terminate TLS.
- Consider a lower `temperature` than 0.7 if you want more consistent grading across
  runs; the current value favours prose quality.
- `max_tokens` is 1600. Pillar II reports are long; raise it if you see truncation
  (truncated output fails JSON parsing and silently drops to the local generator).
