import { betterAuth } from 'better-auth';
import { expo } from '@better-auth/expo';

/**
 * Reference better-auth server instance.
 *
 * This is the counterpart to src/auth/auth.ts in the app. The Apple provider is
 * configured HERE — the client only ever points at this server's URL, which is
 * a public value. Wire your real database adapter in place of the note below.
 *
 * SECURITY: every credential below is read from the environment. Nothing is
 * hardcoded, and nothing here may be copied into app.json / eas.json.
 *   APPLE_CLIENT_ID      your Services ID
 *   APPLE_CLIENT_SECRET  the signed JWT, generated from your .p8 private key
 *   BETTER_AUTH_SECRET   openssl rand -base64 32
 * The .p8 file itself is gitignored and must never be committed. If one is,
 * revoke the key in the Apple Developer portal — deleting it in a later commit
 * does not remove it from history.
 */
export const auth = betterAuth({
  // database: <your adapter>,  // e.g. drizzleAdapter(db) / prismaAdapter(db)
  trustedOrigins: ['obsidiannature://'],
  plugins: [expo()],
  socialProviders: {
    apple: {
      clientId: process.env.APPLE_CLIENT_ID!, // Services ID
      clientSecret: process.env.APPLE_CLIENT_SECRET!, // signed JWT
      appBundleIdentifier: 'org.asphodelpress.obsidiannature',
      scope: ['email', 'name'], // profile + email
    },
  },
});
