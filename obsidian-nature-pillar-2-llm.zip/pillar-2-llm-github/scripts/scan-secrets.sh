#!/usr/bin/env bash
# Fails if anything that looks like a credential is tracked in this repo.
# Run before every push:  npm run audit:secrets
set -uo pipefail
cd "$(dirname "$0")/.."
status=0

echo "1/3  credential-shaped strings"
if grep -rInE \
  "sk-ant-[A-Za-z0-9_-]{10}|sk-[A-Za-z0-9]{32}|ghp_[A-Za-z0-9]{20}|xox[baprs]-|AKIA[0-9A-Z]{16}|BEGIN [A-Z ]*PRIVATE KEY|eyJhbGciOi[A-Za-z0-9]" \
  --exclude-dir=node_modules --exclude-dir=.git . ; then
  echo "   FAIL"; status=1
else echo "   ok"; fi

echo "2/3  assigned secrets (value present, not just the name)"
if grep -rInE \
  "(api[_-]?key|apikey|secret|token|passwd|password)[\"' ]*[:=][\"' ]*[A-Za-z0-9/+_-]{12,}" \
  --exclude-dir=node_modules --exclude-dir=.git --exclude=scan-secrets.sh . ; then
  echo "   FAIL"; status=1
else echo "   ok"; fi

echo "3/3  credential files"
if find . -path ./node_modules -prune -o \
  \( -name '.env' -o -name '*.p8' -o -name '*.p12' -o -name '*.pem' \
     -o -name '*.key' -o -name '*.mobileprovision' -o -name '*.keystore' \) -print | grep . ; then
  echo "   FAIL"; status=1
else echo "   ok"; fi

[ $status -eq 0 ] && echo "PASS — no secrets found" || echo "FAILED — do not push"
exit $status
