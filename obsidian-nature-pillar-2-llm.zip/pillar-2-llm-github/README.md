# Obsidian Nature — Pillar II: The Archetypal

**LLM integration + knowledge base. Secret-free, safe to push to a public repository.**

Everything Pillar II needs to produce an analysis: the archetype set, the
research-backed knowledge base fed to the model, both prompts, the server route, and
deterministic local generators that run when the server is unreachable.

No API keys, tokens, certificates, or credentials. See [SECURITY.md](SECURITY.md).

---

## What's in here

```
src/
  types.ts                      Minimal shared types (delete when merging into the app)
  data/
    archetypesKnowledge.ts      KNOWLEDGE BASE — sourced background sent to the model
    archetypes.ts               18 archetypes + 5 individuation movements
  analysis/
    remote.ts                   LLM calls + automatic fallback   ← the seam
    endpoint.ts                 Authed fetch to your backend. Holds no secrets.
    archetypal.ts               Local generator for the pillar report (von Franz)
    archetypeIntake.ts          Local generator for the intake report
server/
  prompts.ts                    SYSTEM_PROMPT + both prompt builders
  analysis.route.ts             POST /api/analysis/:kind — auth, rate limit, Claude
  auth.ts                       better-auth instance; all credentials from env
  package.json / tsconfig.json  Server deps, installed separately
docs/
  KNOWLEDGE_BASE.md             What's in the knowledge base and where it came from
reference/
  *.tsx.reference               Pillar II screens, for reference only — they import the
                                app's components/, store/ and theme/, which are outside
                                this bundle, so they're excluded from the typecheck
scripts/
  scan-secrets.sh               Pre-push credential audit (npm run audit:secrets)
.env.example                    Template. Copy to .env; .env is gitignored.
```

### By the numbers

| Asset | Count |
|---|---|
| Archetypes (`ARCHETYPES`) | 18 — 6 structural, 12 figures |
| Individuation movements (`INDIVIDUATION`) | 5 |
| Knowledge entries (`ARCHETYPE_KNOWLEDGE`) | 9 |
| Frye's fictional modes (`FRYE_MODES`) | 5 |
| Seasonal archetypes | 4 |
| Attributed quotations | 6 |
| Sources (`ARCHETYPE_SOURCES`) | 13 |
| Briefing sent to the model | ~14,200 characters |

---

## Two LLM paths

Pillar II is the only pillar with two, because it appears twice in the app.

**1 · `archetype-report`** — built during intake from favourite films, books,
fairytales and characters. Surfaces in the **Archetypal Explorations** tab. Sends no
knowledge briefing: it runs before the pillar is opened and is deliberately a lighter
read. Falls back to `analysis/archetypeIntake.ts`.

**2 · `archetypal-pattern`** — the **"Analyze through Jungian Lens"** button inside the
pillar. Takes the analysand's free reflection and reads it through von Franz's
four-step hermeneutic with the full knowledge base attached. Falls back to
`analysis/archetypal.ts`.

```
ArchetypalPillarScreen
      │  await analyzeArchetypalPattern(tone, reflection)
      ▼
src/analysis/remote.ts
      │  POST /api/analysis/archetypal-pattern
      │  { tone, text, knowledge: archetypeKnowledgeBriefing() }
      ▼
server/analysis.route.ts       ← better-auth session check, rate limit
      │  SYSTEM_PROMPT + buildPrompt(...)
      ▼
   Claude  ──────────────────►  strict JSON  ──►  LacanianReport
```

**On any failure** — endpoint unconfigured, offline, timeout, non-2xx, unparseable
JSON — `remote.ts` catches and runs the local generator. Clone this repo with no
backend at all and Pillar II still works end to end.

`analysisConfigured()` treats `localhost`, `example.com`, and any `YOUR_...`
placeholder as *not configured*, so committed placeholder URLs keep the app on the
local generator rather than firing requests at nothing.

---

## Verify it

```bash
npm install
npm run typecheck        # 0 errors across src/
npm run audit:secrets    # PASS — no secrets found
```

## Running it

**Client** — everything under `src/` is dependency-free TypeScript and typechecks on
its own. `endpoint.ts` takes its base URL and session cookie by injection:

```ts
import Constants from 'expo-constants';
import { authClient } from '@/auth/auth';
import { configureAnalysis } from '@/analysis/endpoint';

const extra = (Constants.expoConfig?.extra ?? {}) as Record<string, string>;
configureAnalysis({
  baseUrl: extra.analysisBaseUrl || extra.authBaseUrl || '',
  getCookie: () => (authClient as any).getCookie?.() ?? null,
});
```

**Server**

```bash
cd server
cp ../.env.example .env      # then fill in ANTHROPIC_API_KEY etc.
npm install
npm run dev
```

Mount the router on the **same origin** as better-auth so the session cookie is valid.

---

## Clinical and safety posture

Carried from the main app and enforced in `SYSTEM_PROMPT`:

- **Reality-based only.** No mysticism, magic, spirits, astrology, or energy presented
  as literal. Alchemical and mythic language appears strictly as Jung used it — a
  symbolic vocabulary for psychological process, never a claim about the world.
- **Archetypes are patterns to relate to, never identities to assume.** This is the
  load-bearing constraint of Pillar II and it is written into the prompt itself. The
  prompt explicitly instructs the model that if the material shows someone feeling
  *chosen or special* rather than *more responsible*, it should say so plainly and
  gently. Inflation is the specific failure mode this pillar has to guard against, so
  the knowledge base carries an entire entry (`inflation_and_safety`) on it.
- **Never diagnoses, never treats, never replaces professional care.**
- **Tone switch.** `tone: 'clinician'` rewrites the report as case material for the
  treating analyst; `'patient'` addresses the user as "you".
- **Crisis handling.** Material suggesting risk of self-harm turns the output
  supportive and directs toward professional support rather than deeper analysis.

## License

See [LICENSE](LICENSE). Asphodel Press.
