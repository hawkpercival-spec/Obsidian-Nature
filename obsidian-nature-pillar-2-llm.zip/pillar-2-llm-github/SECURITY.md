# Security

## The one rule

**The LLM API key lives on the server, as an environment variable, and nowhere else.**

Anything bundled into a React Native app ships to every device that installs it. An
IPA is a zip file; a determined person unzips it and reads your strings. There is no
obfuscation that fixes this. So the app never talks to Anthropic — it talks to *your*
backend, and your backend holds the key.

That is the entire reason `src/analysis/endpoint.ts` and `server/analysis.route.ts`
exist as separate files.

## What is in this repository

Nothing sensitive. Specifically:

| | |
|---|---|
| API keys / tokens | none — `analysis.route.ts` reads `process.env.ANTHROPIC_API_KEY` |
| Apple credentials | none — no `.p8`, `.p12`, `.mobileprovision`, or Team ID |
| Auth secrets | none — `BETTER_AUTH_SECRET` is an env var, listed empty in `.env.example` |
| Database URLs | none |
| Personal data | none — no journals, reports, or user records |
| `.env` | not present, and gitignored |

`.env.example` is a **template**: every value is blank or an obvious placeholder. It is
committed on purpose so you know what to fill in.

## Client vs server values

`app.json` → `extra` is **public**. Anything you put there is readable by anyone with
the app. Only these belong in it:

```
extra.analysisBaseUrl   https://your-api-host.example
extra.authBaseUrl       https://your-api-host.example
```

Both are just your own hostname. `analysisConfigured()` deliberately rejects
`localhost`, `example.com`, and `YOUR_*` so placeholder values keep the app on its
offline generator rather than making requests that fail.

Everything else — `ANTHROPIC_API_KEY`, `BETTER_AUTH_SECRET`, `APPLE_KEY_ID`,
`APPLE_PRIVATE_KEY_PATH`, `DATABASE_URL` — is server-only.

## Privacy of the analysis payload

Pillar II requests carry the user's own written reflection and the media they love. Two consequences,
both already implemented:

- `analysis.route.ts` logs the error and the kind, **never the request body**.
- The route requires a valid better-auth session and is rate-limited to 40 requests
  per user per hour. Swap the in-memory limiter for Redis before running more than one
  instance.

Add TLS termination and a retention policy for anything you persist. This bundle
persists nothing server-side.

## Before you push

```bash
git status --porcelain          # .env must not appear
git ls-files | grep -iE '\.(env|p8|p12|pem|key|mobileprovision)$'   # expect no output
```

If a key ever does get committed, rotate it. Removing it in a later commit does not
help — it stays in the history, and history is what gets scraped.
